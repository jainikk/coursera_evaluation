var express = require('express');
var morgan = require('morgan');
var bodyParser = require('body-parser');

var leadershipRouter = express.Router();
leadershipRouter.use(bodyParser.json());

var app = express();
app.use(morgan('dev'));

var hostname = 'localhost';
var port = 3000;


leadershipRouter.route('/')
.all(function(req,res,next) {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    next();
})
.get(function(req,res,next) {
    res.end("Will send all leaderships for you!");
})
.post(function(req,res,next) {
    res.end("will add leadership: "+ req.body.name + " with designation: "+ req.body.role);
})
.delete(function(req,res,next) {
    res.end("deleting all leaderships");
});

leadershipRouter.route('/:leadershipId')
.all(function(req,res,next) {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    next();
})
.get(function(req,res,next) {
    res.end("Will send details of leadership: "+ req.params.leadershipId +" to you!");
})
.put(function(req,res,next) {
    res.write("updating leadership:"+ req.params.leadershipId +"!\n");
    res.end("will update leadership: "+ req.body.name + " with details: "+ req.body.role);
})
.delete(function(req,res,next) {
    res.end("deleting leadership: "+ req.params.leadershipId);
});

module.exports.leadershipRouter = leadershipRouter;
