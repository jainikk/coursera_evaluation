var express = require('express');
var app = express();

var xyz = require('./dishRouter.js');
var xyz1 = require('./promoRouter.js');
var xyz2 = require('./leaderRouter.js');
var hostname = 'localhost';
var port = 3000;

app.use('/dishes',xyz.dishRouter);
app.use('/promotions',xyz1.promotionRouter);
app.use('/leadership',xyz2.leadershipRouter);

app.use(function(req,res,next) {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end('<html><body><h1> server is running successfully </h1></body></html>');
});

app.listen(port, hostname , function() {
    console.log('Server running at http://'+hostname+' on port:'+port);
});
