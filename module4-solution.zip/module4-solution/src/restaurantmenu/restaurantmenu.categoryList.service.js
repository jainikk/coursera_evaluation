/*(function () {
'use strict';

angular.module('RestaurantMenu')
.service('CategoryListService', CategoryListService);


CategoryListService.$inject = ['$q', '$timeout']
function CategoryListService($q, $timeout) {
  var service = this;

  // List of shopping items
  var category = [];

  // Pre-populate a no cookie list
  category.push('Veg','Non-Veg','Punjabi','Italian','South-Indian','Fast-Food');

  // Simulates call to server
  // Returns a promise, NOT items array directly
 /* service.getCategoryList = function () {
    var deferred = $q.defer();

    // Wait 2 seconds before returning
    $timeout(function () {
      // deferred.reject(items);
      deferred.resolve(category);
    }, 800);

    return deferred.promise;
  };
}

})(); */
