(function () {
'use strict';

angular.module('RestaurantMenu', ['ui.router']);

})();
