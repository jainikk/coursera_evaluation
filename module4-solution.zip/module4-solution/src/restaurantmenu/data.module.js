(function () {
'use strict';

angular.module('data', ['ui.router']);

})();
