(function () {
'use strict';

angular.module('data')
.service('MenuDataService', MenuDataService);


MenuDataService.$inject = ['$q', '$timeout','$http']
function MenuDataService($q, $timeout,$http) {
    // alert('hi');
  var service = this;

  // List of shopping categories


  // Pre-populate a no cookie list
  //categories.push('Veg','Non-Veg','Punjabi','Italian','South-Indian','Fast-Food');

  // Simulates call to server
  // Returns a promise, NOT categories array directly
  service.getAllCategories = function () {
    var deferred = $q.defer();

    // Wait 2 seconds before returning

      $timeout(function() {

      $http.get('http://davids-restaurant.herokuapp.com/categories.json')
            .success(function (data, status, headers, config) {
            deferred.resolve(data);
            })
            .error(function (data, status, header, config) {

                deferred.resolve(data);
            });
        } , 800);
        return deferred.promise;
        };


        service.getItemsForCategory = function (categoryName) {
            alert("hi of service");
          var deferred = $q.defer();

          // Wait 2 seconds before returning

            $timeout(function() {
                var link = "https://davids-restaurant.herokuapp.com/menu_items.json?category="+ categoryName ;

            $http.get(link)
                  .success(function (data, status, headers, config) {
                      console.log(data);
                  deferred.resolve(data);
                  })
                  .error(function (data, status, header, config) {

                      deferred.resolve(data);
                  });
              } , 800);
              return deferred.promise;
              };


}

})();
